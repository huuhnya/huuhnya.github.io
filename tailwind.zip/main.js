new Vue({
	el: '#app',
	data:{
		toggle: true,
		loader: false,
		toggleDetail: false,
	},
	methods:{
		
	}
});